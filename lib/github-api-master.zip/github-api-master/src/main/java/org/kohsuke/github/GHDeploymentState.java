package org.kohsuke.github;

/**
 * Represents the state of deployment
 */
public enum GHDeploymentState {
    PENDING, SUCCESS, ERROR, FAILURE
}
