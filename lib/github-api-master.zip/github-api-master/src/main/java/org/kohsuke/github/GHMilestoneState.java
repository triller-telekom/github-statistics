package org.kohsuke.github;

/**
 * 
 * @author Yusuke Kokubo
 *
 */
public enum GHMilestoneState {
    OPEN,
    CLOSED
}