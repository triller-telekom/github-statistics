package org.kohsuke.github;

/**
 * @author Kohsuke Kawaguchi
 */
public enum GHPermissionType {
    ADMIN,
    WRITE,
    READ,
    NONE
}
