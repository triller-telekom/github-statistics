package org.kohsuke.github;

/**
 * Sort direction
 *
 * @author Kohsuke Kawaguchi
 */
public enum GHDirection {
    ASC, DESC
}
