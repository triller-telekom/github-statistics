package org.kohsuke.github;

/**
 * @author Kohsuke Kawaguchi
 */
class JsonRateLimit {
    GHRateLimit rate;
}
